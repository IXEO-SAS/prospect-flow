import { create } from 'zustand';

// Store principal
export const useProspectStore = create((set, get) => ({
  // Auth & Users
  currentUser: null,
  users: [], // {id, name, email, role: 'commercial'|'manager', color}
  
  setCurrentUser: (user) => set({ currentUser: user }),
  addUser: (user) => set((state) => ({ users: [...state.users, user] })),
  
  // Contacts
  contacts: [],
  addContact: (contact) => set((state) => ({
    contacts: [...state.contacts, {
      id: Date.now(),
      createdAt: new Date().toISOString(),
      ...contact,
    }],
  })),
  updateContact: (id, updates) => set((state) => ({
    contacts: state.contacts.map(c => c.id === id ? { ...c, ...updates } : c),
  })),
  deleteContact: (id) => set((state) => ({
    contacts: state.contacts.filter(c => c.id !== id),
  })),
  setContacts: (contacts) => set({ contacts }),
  
  // Campagnes de prospection
  campaigns: [],
  addCampaign: (campaign) => set((state) => ({
    campaigns: [...state.campaigns, {
      id: Date.now(),
      createdAt: new Date().toISOString(),
      status: 'active', // 'active', 'paused', 'completed'
      ...campaign,
    }],
  })),
  updateCampaign: (id, updates) => set((state) => ({
    campaigns: state.campaigns.map(c => c.id === id ? { ...c, ...updates } : c),
  })),
  
  // Historique actions
  actions: [],
  addAction: (action) => set((state) => ({
    actions: [...state.actions, {
      id: Date.now(),
      timestamp: new Date().toISOString(),
      ...action,
    }],
  })),
  getContactActions: (contactId) => {
    const { actions } = get();
    return actions.filter(a => a.contactId === contactId).sort((a, b) => 
      new Date(b.timestamp) - new Date(a.timestamp)
    );
  },
  
  // Notifications
  notifications: [],
  addNotification: (notification) => set((state) => ({
    notifications: [...state.notifications, {
      id: Date.now(),
      ...notification,
    }],
  })),
  removeNotification: (id) => set((state) => ({
    notifications: state.notifications.filter(n => n.id !== id),
  })),
  
  // Persistence localStorage
  persistState: () => {
    const state = get();
    localStorage.setItem('prospect-app-state', JSON.stringify({
      contacts: state.contacts,
      campaigns: state.campaigns,
      actions: state.actions,
      users: state.users,
    }));
  },
  
  loadState: () => {
    const saved = localStorage.getItem('prospect-app-state');
    if (saved) {
      const { contacts, campaigns, actions, users } = JSON.parse(saved);
      set({ contacts, campaigns, actions, users });
    }
  },
}));

// Persister après chaque changement
useProspectStore.subscribe((state) => {
  state.persistState();
});
