import React, { useState } from 'react';
import { useProspectStore } from '../store';
import { Users, LogIn } from 'lucide-react';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState('commercial');
  const setCurrentUser = useProspectStore(s => s.setCurrentUser);
  const addUser = useProspectStore(s => s.addUser);
  const users = useProspectStore(s => s.users);

  const colors = ['#8b5cf6', '#06b6d4', '#ec4899', '#f59e0b', '#10b981'];

  const handleLogin = (e) => {
    e.preventDefault();
    const newUser = {
      id: Date.now(),
      email,
      name,
      role,
      color: colors[Math.floor(Math.random() * colors.length)],
    };
    addUser(newUser);
    setCurrentUser(newUser);
  };

  const handleQuickLogin = (exampleUser) => {
    setCurrentUser(exampleUser);
  };

  return (
    <div className="min-h-screen bg-gradient-nocr flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-white/20 mb-4">
            <Users className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-2">ProspectFlow</h1>
          <p className="text-white/80">Campagnes de prospection efficaces</p>
        </div>

        {/* Form */}
        <div className="bg-white rounded-2xl shadow-xl p-8 mb-6">
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Nom
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Votre nom"
                className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Email
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="votre@email.com"
                className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Rôle
              </label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
              >
                <option value="commercial">Commercial</option>
                <option value="manager">Manager</option>
              </select>
            </div>

            <button
              type="submit"
              className="w-full bg-gradient-nocr text-white py-3 rounded-lg font-semibold hover:opacity-90 transition flex items-center justify-center gap-2 mt-6"
            >
              <LogIn className="w-5 h-5" />
              Connexion
            </button>
          </form>

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-200"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white text-gray-500">ou</span>
            </div>
          </div>

          {/* Démo rapide */}
          <div className="space-y-2">
            <p className="text-xs text-gray-500 text-center mb-3">Démo rapide :</p>
            {[
              { name: 'Marie (Commercial)', role: 'commercial', email: 'marie@ixeo.fr' },
              { name: 'Luc (Manager)', role: 'manager', email: 'luc@ixeo.fr' },
            ].map((u) => (
              <button
                key={u.email}
                onClick={() => {
                  setName(u.name);
                  setEmail(u.email);
                  setRole(u.role);
                  setTimeout(() => handleQuickLogin({
                    id: Date.now(),
                    email: u.email,
                    name: u.name,
                    role: u.role,
                    color: u.role === 'commercial' ? '#06b6d4' : '#8b5cf6',
                  }), 100);
                }}
                className="w-full px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50 text-sm text-gray-700 transition"
              >
                {u.name}
              </button>
            ))}
          </div>
        </div>

        <p className="text-center text-white/70 text-sm">
          Demo v1.0 • Données stockées localement
        </p>
      </div>
    </div>
  );
}
