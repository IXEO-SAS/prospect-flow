import React, { useState, useMemo } from 'react';
import { MapPin, Phone, LogOut, Plus, Map, List, ChevronDown, CheckCircle, Circle } from 'lucide-react';
import { useProspectStore } from '../store';
import ContactDetail from './ContactDetail';
import ProspectionCampaign from './ProspectionCampaign';
import MapView from './MapView';

const statusColors = {
  new: 'bg-red-100 text-red-700',
  contacted: 'bg-yellow-100 text-yellow-700',
  action: 'bg-green-100 text-green-700',
};

export default function CommercialDashboard() {
  const [viewMode, setViewMode] = useState('list'); // 'list' ou 'map'
  const [selectedContact, setSelectedContact] = useState(null);
  const [showImportModal, setShowImportModal] = useState(false);
  const [showCampaignModal, setShowCampaignModal] = useState(false);
  const [expandedContact, setExpandedContact] = useState(null);

  const currentUser = useProspectStore(s => s.currentUser);
  const contacts = useProspectStore(s => s.contacts);
  const campaigns = useProspectStore(s => s.campaigns);
  const setCurrentUser = useProspectStore(s => s.setCurrentUser);
  const updateContact = useProspectStore(s => s.updateContact);

  // Campagne active du commercial
  const activeCampaign = campaigns.find(
    c => c.commercialId === currentUser?.id && c.status === 'active'
  );

  // Contacts à prospecter (si campagne active) ou tous les contacts
  const contactsToShow = useMemo(() => {
    if (activeCampaign) {
      const campaignContactIds = activeCampaign.contacts.map(c => c.id);
      return contacts
        .filter(c => campaignContactIds.includes(c.id))
        .sort((a, b) => {
          const distA = activeCampaign.contacts.find(c => c.id === a.id)?.distance || 0;
          const distB = activeCampaign.contacts.find(c => c.id === b.id)?.distance || 0;
          return distA - distB;
        });
    }
    return contacts;
  }, [contacts, activeCampaign]);

  const handleLogout = () => {
    setCurrentUser(null);
  };

  const handleCyclestatus = (contact) => {
    const statuses = ['new', 'contacted', 'action'];
    const currentIndex = statuses.indexOf(contact.status);
    const nextStatus = statuses[(currentIndex + 1) % statuses.length];
    updateContact(contact.id, { status: nextStatus });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">ProspectFlow</h1>
            <p className="text-gray-600">Bienvenue, {currentUser?.name}</p>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition"
          >
            <LogOut className="w-5 h-5" />
            Déconnexion
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Stats et actions */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-lg shadow p-4">
            <p className="text-gray-600 text-sm">Total contacts</p>
            <p className="text-3xl font-bold text-gray-900">{contactsToShow.length}</p>
          </div>
          <div className="bg-white rounded-lg shadow p-4">
            <p className="text-gray-600 text-sm">Non contactés</p>
            <p className="text-3xl font-bold text-red-500">
              {contactsToShow.filter(c => c.status === 'new').length}
            </p>
          </div>
          <div className="bg-white rounded-lg shadow p-4">
            <p className="text-gray-600 text-sm">Actions en cours</p>
            <p className="text-3xl font-bold text-green-500">
              {contactsToShow.filter(c => c.status === 'action').length}
            </p>
          </div>
          <div className="bg-white rounded-lg shadow p-4">
            {activeCampaign ? (
              <>
                <p className="text-gray-600 text-sm">Campagne active</p>
                <p className="text-sm font-semibold text-primary-600">
                  📍 Rayon: {activeCampaign.radius} km
                </p>
              </>
            ) : (
              <>
                <p className="text-gray-600 text-sm">Campagne</p>
                <button
                  onClick={() => setShowCampaignModal(true)}
                  className="mt-2 w-full bg-gradient-nocr text-white py-2 rounded-lg font-semibold hover:opacity-90 transition text-sm flex items-center justify-center gap-1"
                >
                  <Plus className="w-4 h-4" /> Nouvelle
                </button>
              </>
            )}
          </div>
        </div>

        {/* Mode selection */}
        <div className="flex gap-2 mb-4">
          <button
            onClick={() => setViewMode('list')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg transition ${
              viewMode === 'list'
                ? 'bg-primary-500 text-white'
                : 'bg-white border border-gray-200 text-gray-700 hover:bg-gray-50'
            }`}
          >
            <List className="w-5 h-5" />
            Liste
          </button>
          <button
            onClick={() => setViewMode('map')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg transition ${
              viewMode === 'map'
                ? 'bg-primary-500 text-white'
                : 'bg-white border border-gray-200 text-gray-700 hover:bg-gray-50'
            }`}
          >
            <Map className="w-5 h-5" />
            Carte
          </button>
        </div>

        {/* Content */}
        {viewMode === 'list' ? (
          <div className="space-y-2">
            {contactsToShow.length === 0 ? (
              <div className="bg-white rounded-lg shadow p-8 text-center">
                <MapPin className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500">Aucun contact</p>
              </div>
            ) : (
              contactsToShow.map(contact => (
                <div key={contact.id} className="bg-white rounded-lg shadow hover:shadow-md transition">
                  <div
                    onClick={() => setExpandedContact(expandedContact === contact.id ? null : contact.id)}
                    className="p-4 cursor-pointer flex items-start justify-between"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-1">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleCyclestatus(contact);
                          }}
                          className={`flex-shrink-0 rounded-full p-1 transition ${statusColors[contact.status]}`}
                        >
                          <Circle className="w-5 h-5" />
                        </button>
                        <h3 className="font-semibold text-gray-900">{contact.raisonSociale}</h3>
                      </div>
                      <p className="text-sm text-gray-600 ml-8">{contact.dirigeant}</p>
                      <p className="text-xs text-gray-500 ml-8 flex items-center gap-1 mt-1">
                        <MapPin className="w-3 h-3" />
                        {contact.adresse}
                      </p>
                      {activeCampaign && (
                        <p className="text-xs text-primary-600 ml-8 mt-1">
                          📍 {(activeCampaign.contacts.find(c => c.id === contact.id)?.distance || 0).toFixed(1)} km
                        </p>
                      )}
                    </div>
                    <ChevronDown className={`w-5 h-5 text-gray-400 transition ${expandedContact === contact.id ? 'rotate-180' : ''}`} />
                  </div>

                  {expandedContact === contact.id && (
                    <div className="border-t border-gray-200 px-4 py-4 bg-gray-50 space-y-3">
                      {contact.telephone && (
                        <div className="flex items-center gap-2">
                          <Phone className="w-4 h-4 text-gray-600" />
                          <a href={`tel:${contact.telephone}`} className="text-primary-600 hover:underline">
                            {contact.telephone}
                          </a>
                        </div>
                      )}
                      {contact.libelleNaf && (
                        <div>
                          <p className="text-xs text-gray-500 font-semibold uppercase">Secteur</p>
                          <p className="text-sm text-gray-700">{contact.libelleNaf}</p>
                        </div>
                      )}
                      <div className="flex gap-2 pt-2">
                        <button
                          onClick={() => setSelectedContact(contact)}
                          className="flex-1 bg-primary-500 text-white py-2 rounded-lg text-sm font-semibold hover:bg-primary-600 transition"
                        >
                          Ouvrir fiche
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        ) : (
          <MapView contacts={contactsToShow} onSelectContact={setSelectedContact} />
        )}
      </div>

      {/* Modals */}
      {selectedContact && (
        <ContactDetail contact={selectedContact} onClose={() => setSelectedContact(null)} />
      )}
      {showCampaignModal && (
        <ProspectionCampaign onClose={() => setShowCampaignModal(false)} />
      )}
    </div>
  );
}
